﻿
Kortlagning á jarðleiðni Íslands
- Upplýsingar um meðfylgjandi skjöl -

gogn.xlsx       : Inniheldur öll uppsöfnuð gögn á þremur síðum
gogn.db         : Gagnagrunnsskrá sem búin var til í gagnagrunnskerfinu SQLite
gogn_sqlite.sql : Inniheldur skipanir sem hægt er að keyra til að setja upp SQLite gagnagrunn
gogn_mysql.sql  : Inniheldur skipanir sem hægt er að keyra til að setja upp MySQL gagnagrunn

maelingar.csv,
punktar.csv,
sendar.csv      : CSV skrár með öllum síðunum úr Excel-skránni gogn.xlsx


Fyrirspurnir um frekari upplýsingar eða gögn berist til eftirfarandi:

Sæmundur E. Þorsteinsson
Kristinn Andersen
Valentin Oliver Loftsson

-------------------------------------
Höfundur: Valentin Oliver Loftsson
30. ágúst 2017